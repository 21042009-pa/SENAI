from machine import Pin
from utime import sleep_us, sleep
import dht
import time

# ============================================
# Sensores
# ============================================

sensor_dht = dht.DHT22(Pin(14))

sensor_pir = Pin(15, Pin.IN)

trigger = Pin(22, Pin.OUT)
echo = Pin(21, Pin.IN)

# ============================================
# Atuadores
# ============================================

led = Pin(17, Pin.OUT)
buzzer = Pin(16, Pin.OUT)

# ============================================
# Configurações
# ============================================

TEMPERATURA_LIMITE = 26
DISTANCIA_LIMITE = 50

# ============================================
# Função ultrassônica
# ============================================

def medir_distancia():

    trigger.off()
    sleep_us(2)

    trigger.on()
    sleep_us(10)
    trigger.off()

    timeout = 30000

    inicio_espera = time.ticks_us()

    # Espera início do eco
    while echo.value() == 0:

        if time.ticks_diff(time.ticks_us(), inicio_espera) > timeout:
            return None

    inicio = time.ticks_us()

    # Espera fim do eco
    while echo.value() == 1:

        if time.ticks_diff(time.ticks_us(), inicio) > timeout:
            return None

    fim = time.ticks_us()

    duracao = time.ticks_diff(fim, inicio)

    distancia = (duracao * 0.0343) / 2

    return distancia

# ============================================
# Loop principal
# ============================================

while True:

    try:

        # DHT22
        sensor_dht.measure()
        temperatura = sensor_dht.temperature()

        # PIR
        pir = sensor_pir.value()

        # Ultrassônico
        distancia = medir_distancia()

        # Se falhar leitura
        if distancia is None:
            print("Erro no ultrassônico")
            sleep(1)
            continue

        # ====================================
        # Lógica
        # ====================================

        if (
            pir == 1
            and distancia <= DISTANCIA_LIMITE
            and temperatura >= TEMPERATURA_LIMITE
        ):

            led.on()
            buzzer.on()
            sistema = 1

        else:

            led.off()
            buzzer.off()
            sistema = 0

        # ====================================
        # Dashboard
        # ====================================

        print("temperatura:", temperatura, "°C")
        print("pir:", pir)
        print("distancia:", round(distancia, 2), "cm")
        print("sistema:", sistema)

        print("-----------------------")

    except Exception as erro:

        print("Erro:", erro)

    sleep(2)