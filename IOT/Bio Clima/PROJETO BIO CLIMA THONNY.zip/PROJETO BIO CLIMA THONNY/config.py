# WiFi
WIFI_SSID = "WIFI_IOT"
WIFI_PASS = "Ac1ce2ss5@IOT"

# MQTT
BROKER_IP = "10.132.112.4"
BROKER_PORT = 1883

# Identificação
MEU_NOME = "grupo3"
CLIENT_ID = f"pico_{MEU_NOME.lower()}"

# Tópicos MQTT
TOPIC_PUB = f"senai/{MEU_NOME.lower()}/sensores"
TOPIC_SUB = f"senai/{MEU_NOME.lower()}/comandos"

# Intervalo de publicação
INTERVALO_PUB = 1