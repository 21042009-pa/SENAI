from machine import Pin, PWM
from utime import sleep_us, sleep
from umqtt.simple import MQTTClient
from config import *
from wifi_connect import conectar_wifi

import dht
import time
import json # Biblioteca para formatar a mensagem

# ============================================
# Sensores
# ============================================

sensor_dht = dht.DHT22(Pin(14))
sensor_pir = Pin(15, Pin.IN)

trigger = Pin(22, Pin.OUT)
echo = Pin(21, Pin.IN)

# ============================================
# Atuadores
# ============================================

led = Pin(17, Pin.OUT)
buzzer = PWM(Pin(16))

# ============================================
# Configurações
# ============================================

TEMPERATURA_LIMITE = 20
DISTANCIA_LIMITE = 50

sistema_habilitado = True

# ============================================
# MQTT Callback
# ============================================

def receber_mensagem(topic, msg):

    global sistema_habilitado

    comando = msg.decode()

    print("Comando recebido:", comando)

    if comando == "ON":
        sistema_habilitado = True

    elif comando == "OFF":
        sistema_habilitado = False
        led.off()
        buzzer.duty_u16(0)

# ============================================
# Ultrassônico
# ============================================

def medir_distancia():

    trigger.off()
    sleep_us(2)

    trigger.on()
    sleep_us(10)
    trigger.off()

    timeout = 30000

    inicio_espera = time.ticks_us()

    while echo.value() == 0:

        if time.ticks_diff(time.ticks_us(), inicio_espera) > timeout:
            return None

    inicio = time.ticks_us()

    while echo.value() == 1:

        if time.ticks_diff(time.ticks_us(), inicio) > timeout:
            return None

    fim = time.ticks_us()

    duracao = time.ticks_diff(fim, inicio)

    distancia = (duracao * 0.0343) / 2

    return distancia

# ============================================
# WiFi
# ============================================

if not conectar_wifi(WIFI_SSID, WIFI_PASS):

    raise Exception("Sem WiFi")

# ============================================
# MQTT
# ============================================

cliente = MQTTClient(
    CLIENT_ID,
    BROKER_IP,
    port=BROKER_PORT
)

cliente.set_callback(receber_mensagem)

cliente.connect()

cliente.subscribe(TOPIC_SUB)

print("MQTT conectado")

# ============================================
# Loop principal
# ============================================

while True:

    try:

        cliente.check_msg()

        sensor_dht.measure()

        temperatura = sensor_dht.temperature()
        umidade = sensor_dht.humidity()

        pir = sensor_pir.value()

        distancia = medir_distancia()

        if distancia is None:
            continue

        # ====================================
        # Lógica do sistema
        # ====================================

        if sistema_habilitado:

            if (
                pir == 1
                and distancia <= DISTANCIA_LIMITE
                and temperatura >= TEMPERATURA_LIMITE
            ):

                led.on()

                buzzer.freq(1000)
                buzzer.duty_u16(30000)

                estado = 1

            else:

                led.off()
                buzzer.duty_u16(0)

                estado = 0

        else:

            led.off()
            buzzer.duty_u16(0)

            estado = 0

        # ====================================
        # Publish MQTT
        # ====================================

        dados = {
            "temperatura": temperatura,
            "umidade": umidade,
            "pir": pir,
            "distancia": round(distancia, 2),
            "sistema": estado 
        }
        
        mensagem = json.dumps(dados)

        cliente.publish(
            TOPIC_PUB,
            mensagem.encode()
        )

        print("Enviado:", mensagem)

    except Exception as erro:

        print("Erro:", erro)

    sleep(2)